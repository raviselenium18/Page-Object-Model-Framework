package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import base.Page;

public class MyProfilePage extends Page {
	
	
	public void gotoAbout() {
		
		
	}
	
	
	public void gotoFriends() {
		
		
	}
	
	
	
	public MyProfilePage uploadPhoto() {
		
		
		//driver.findElement(By.xpath("//a[starts-with(@id,'u_fetchstream_')][@rel='dialog']")).click();
		//driver.findElement(By.xpath("//a[@data-action-type='upload_photo']/div/input")).sendKeys("C:\\Users\\WAY2AUTOMATION\\Desktop\\se.png");
		System.out.println("Photo uploaded !!!");
		
		return this;
	
	}
}
