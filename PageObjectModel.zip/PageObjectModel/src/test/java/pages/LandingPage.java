package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import base.Page;

public class LandingPage extends Page{
	
	

	
	
	public MyProfilePage gotoProfile() {
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.xpath("//*[@id=\"navItem_100010051393565\"]/a/div")).click();
		
		return new MyProfilePage();
	
	}
	
	public void updateStatus() {
		
		
	}
	
	
	public void gotoPages() {
		
		
		
	}

}
