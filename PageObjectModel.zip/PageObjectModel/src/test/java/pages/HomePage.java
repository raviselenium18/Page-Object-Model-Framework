package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import base.Page;

public class HomePage extends Page{
	/*
	 * logs
	 * keywords
	 * excel
	 * properties
	 * 
	 * 
	 * 
	 * 
	 */
	
	
	public LandingPage doLogin(String username, String password) {
		
		driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys(username);
		driver.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys(password);
		driver.findElement(By.xpath("//input[@type=\"submit\"]")).click();
		return new LandingPage();
	
	}
	
	
	public void createAccount(String email, int phonenum) {
		
		
	}

	
	
	public void validateLinks() {
		
		
		
	}
}
